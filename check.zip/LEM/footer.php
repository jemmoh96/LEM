<footer>
            <div class="footer-info">
                <div class="container">
                    <div class="footer-branding">
                        <div class="title">
                            <h1 class="Loyonese Ministries">Loyonese <span>Evangelical Ministries</span></h1>
                        </div>
                    </div>
                    <div class="site-copyright">
                        <p> Copyright &copy; <?php echo date ("Y");
						?> <br />All rights reserved.</p>
                    </div>
                </div>
            </div>
        </footer>
    </body>
</html>