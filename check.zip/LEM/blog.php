<!DOCTYPE HHTML>
<?php
include_once 'header.php';
?>
        <section class="site-content">
            <div class="container">
                <div class="content-area">
                    <main class="site-main">
                        <div class="posts">
                            <div class="posts-list">
                                <article class="posts-list">
                                    <div class="entry">
                                        <h2 class="entry-title">Weaker shilling makes life cheaper for Nairobi expats</h2>
                                        <div class="entry-divs">
                                            <a href="#">July 2, 2016</a>
                                        </div>
                                    </div>
                                    <div class="entry-thumb">
                                        <a href="#">
                                            <img src="img/305_1.jpg">
                                        </a>
                                    </div>
                                    <div class="entry-disc">
                                        <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr,  sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>
                                    </div>
                                    <div class="btn">
                                        <a class="bttn" href="#">
                                            read more
                                        </a>
                                    </div>
                                </article>
                                <article class="posts-list">
                                    <div class="entry">
                                        <h2 class="entry-title">the first tittle</h2>
                                        <div class="entry-divs">
                                            <a href="#">July 2, 2016</a>
                                        </div>
                                    </div>
                                    <div class="entry-thumb">
                                        <a href="#">
                                            <img src="img/305_1.jpg">
                                        </a>
                                    </div>
                                    <div class="entry-disc">
                                        <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr,  sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>
                                    </div>
                                    <div class="btn">
                                        <a class="bttn" href="#">
                                            read more
                                        </a>
                                    </div>
                                </article>
                                <article class="posts-list">
                                    <div class="entry">
                                        <h2 class="entry-title">the first tittle</h2>
                                        <div class="entry-divs">
                                            <a href="#">July 2, 2016</a>
                                        </div>
                                    </div>
                                    <div class="entry-thumb">
                                        <a href="#">
                                            <img src="img/305_1.jpg">
                                        </a>
                                    </div>
                                    <div class="entry-disc">
                                        <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr,  sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>
                                    </div>
                                    <div class="btn">
                                        <a class="bttn" href="#">
                                            read more
                                        </a>
                                    </div>
                                </article>
                            </div>
                        </div>
                    </main>
                </div>
            </div>
        </section>
   
<?php
include_once 'footer.php';
?>