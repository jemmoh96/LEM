<!DOCTYPE HHTML>
<?php
include_once 'header.php';
?>
<!DOCTYPE HHTML>
<?php
include_once 'header.php';
?>
        <section class="site-content">
            <div class="container">
                <div class="content-area">
                    <main class="site-main">
					<article class="posts-list">
                                <div class="entry-header">
                                 <h1 class="entry-title">LOYONESS EVANGELICAL MINISTRY</h1>
                             </div> 
                             <div class="entry-disc">
                                        <p>
LOYONESS means LOve YOur NEighbour aS you yourSelf. This is also a commandment in the bible,<br /> and love is the greatest commandment. Love withstands the test of time, and up to date, it has done so, regardless of the challenges and test of time.
This minitry began in <date> by a group of women who were dedicated to helping the disadvantaged in the society.<br />
They donated clothes and food stuff. <br />Every year they would visit a slum or a place where people really need help and stand with them. <br />
There is a church in Kibera, Soweto -Undugu ground called Jesus The Cornerstone Church (JTCC) courtecy of this ministry. It is growing. <br /><b><i>The goal of the ministry is to bring many to Christ</i></b>.
 </p>
                             </div> 
							</article>
                              <div class="row">
										<div class="entry-header">
                                 <h1 class="entry-title" align="center">APOSTLE EVA LUWUM</h1>
                             </div>
                            <div align="center" class="abt-left">
                                 <img src="img/eva.jpg">
										</div>
                            <div class="abt-right">
                                <div class="featred-disc">
                                    <div class="index-content">
                                        <p>
										Apostle Eva -the blessed, is the founder of JTCC, which began in 2012 and it is <?php echo date("Y")-2012?> years old in the kibera and still growing. She was also one of LOYONESS founders.
										</b></p>
                                    </div>
                                </div>
                            </div>
                        </div>
					<article class="posts-list">
                                 
							</article>
						<div class="row">
                             <div class="abt-right">
                                
									<img src="img/Maggy.jpg">                                    
                                    
                                </div>
                            						
                            <div align="center" class="abt-left">
							<div class="featred-disc">
                                    <div class="index-content">
                                  <p><h2><u>Pastor Margret</u></h2>
										She is the pastor in JTCC and working under Apostle Eva, <br />who is also a good friend of hers. They were working in the<br /> same organisation before Aposle Eva resigned and <br />together they are spreading the good news about Christ.
										</p>
										</div>
                            </div>
                        </div> </div>
						<article class="posts-list">
                               
                             </article>
							
						<div class="row">
                            <div align="center" class="abt-left">
                                 <img src="img/Eric.jpg">
										</div>
                            <div class="abt-right">
                                <div class="featred-disc">
                                    <div class="index-content">
                                        <p><h2><u>Pastor Eric</u></h2>
										Pastor Eric is the youth pastor<br />
										His life is a living testimony that surely God reigns and<br /> protect those who run to him for a hiding place <br />
										</p>
                                    </div>
                                </div>
                            </div>
                        </div> 
						<br />
                        <article class="posts-list">
                        <div class="comments-area">
                            <div class="comment-respond">
                                <h3>leave a reply</h3>
                                <form>
                                        <label>comment</label>
                                        <textarea></textarea>
                                        <div class="btn">
                                        <a class="bttn" href="#">
                                            post
                                        </a>
                                    </div>
                                </form>
                            </div>
                        </div> </article>
                    </main>
                </div>
            </div>
        </section>
 
 <?php
include_once 'footer.php';
?>

<?php
include_once 'footer.php';
?>
     