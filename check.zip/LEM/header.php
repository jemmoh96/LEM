<html>
    <head>
        <title>Loyonese Evangelical Ministries</title>
        <meta charset="utf-8">
		<style type="text/css">
		#nav{
			margin-top:-15;
			margin-left:5;
		}
		</style>
        <link href="css/style.css" type="text/css" rel="stylesheet" />
        <link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,700' /> 
    </head>
    <body>
        <header>
            <div class="wrapper">
                <div class="title">
				
                    <h1><div id="nav"><img src="img/icon.jpg"><span class="Ministries">Loyonese Evangelical Ministries</span></div></h1>
                </div> <br> </br>
                <div class="menu">
                    <nav>
                        <ul>
                            <li><a href="index.php" class="selected">home</a></li>
                            <li><a href="about.php" class="selected">about</a></li>
                            <li><a href="blog.php" class="selected">blog</a></li>
                            <li><a href="gallery.php" class="selected">gallery</a></li>
                            <li><a href="Events.php" class="selected">Events</a></li>
                            <li><a href="Contacts.php" class="selected">Contact</a></li>
                        </ul>
                    </nav>
                </div>
            </div>
			<meta name = "view" content ="width=device-width, initial-scale=1.0">
        </header> 